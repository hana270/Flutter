class Classe{
  int nbreEtud;
  String nomClass;
  int? codClass;
  Classe(this.nbreEtud, this.nomClass, [this.codClass]  );
}