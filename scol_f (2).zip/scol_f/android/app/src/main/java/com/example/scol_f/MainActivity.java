package com.example.scol_f;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
