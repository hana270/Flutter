import 'package:ProjetFlutter/Utils/constants.dart';
import 'package:ProjetFlutter/Widget/food_items_display.dart';
import 'package:ProjetFlutter/Widget/my_icon_button.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import '../database_helper.dart';

class ViewAllItems extends StatefulWidget {
  const ViewAllItems({super.key});

  @override
  State<ViewAllItems> createState() => _ViewAllItemsState();
}

class _ViewAllItemsState extends State<ViewAllItems> {
  late Future<List<Map<String, dynamic>>> _recipes;

  @override
  void initState() {
    super.initState();
    _recipes = DatabaseHelper().fetchRecipes(); // Fetch recipes from MySQL
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kbackgroundColor,
      appBar: AppBar(
        backgroundColor: kbackgroundColor,
        automaticallyImplyLeading: false,
        elevation: 0,
        actions: [
          const SizedBox(width: 15),
          MyIconButton(
            icon: Icons.arrow_back_ios_new,
            pressed: () {
              Navigator.pop(context);
            },
          ),
          const Spacer(),
          const Text(
            "Quick & Easy",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const Spacer(),
          MyIconButton(
            icon: Iconsax.notification,
            pressed: () {},
          ),
          const SizedBox(width: 15),
        ],
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _recipes,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          if (snapshot.hasError) {
            return Center(child: Text('Erreur: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('Aucune recette trouvée'));
          }

          var recipes = snapshot.data!;

          return SingleChildScrollView(
            padding: const EdgeInsets.only(left: 15, right: 5),
            child: Column(
              children: [
                const SizedBox(height: 10),
                GridView.builder(
                  itemCount: recipes.length,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.78,
                  ),
                  itemBuilder: (context, index) {
                    var recipe = recipes[index];

                    return Column(
                      children: [
                        FoodItemsDisplay(
                            recipe: recipe), // Pass recipe data here
                        Row(
                          children: [
                            const Icon(
                              Iconsax.star1,
                              color: Colors.amberAccent,
                            ),
                            const SizedBox(width: 5),
                            Text(
                              recipe['rate'],
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const Text("/5"),
                            const SizedBox(width: 5),
                            Text(
                              "${recipe['reviews']} Reviews",
                              style: const TextStyle(
                                color: Colors.grey,
                              ),
                            ),
                          ],
                        ),
                      ],
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
