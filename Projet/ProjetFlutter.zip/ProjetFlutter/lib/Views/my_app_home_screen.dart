import 'package:flutter/material.dart';

import '../database_helper.dart';
import 'recipe_detail_screen.dart';

class MyAppHomeScreen extends StatefulWidget {
  @override
  _MyAppHomeScreenState createState() => _MyAppHomeScreenState();
}

class _MyAppHomeScreenState extends State<MyAppHomeScreen> {
  late Future<List<Map<String, dynamic>>> _recipes;

  @override
  void initState() {
    super.initState();
    _recipes = DatabaseHelper().fetchRecipes();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Recettes')),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _recipes,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Erreur: ${snapshot.error}'));
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('Aucune recette disponible.'));
          } else {
            var recipes = snapshot.data!;
            return ListView.builder(
              itemCount: recipes.length,
              itemBuilder: (context, index) {
                var recipe = recipes[index];
                return ListTile(
                  title: Text(recipe['name']),
                  subtitle: Text(recipe['description']),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            RecipeDetailScreen(recipeId: recipe['id']),
                      ),
                    );
                  },
                );
              },
            );
          }
        },
      ),
    );
  }
}
