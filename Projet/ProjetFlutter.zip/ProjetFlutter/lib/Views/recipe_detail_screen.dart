import 'package:flutter/material.dart';

import '../database_helper.dart';

class RecipeDetailScreen extends StatefulWidget {
  final int recipeId; // Accept recipe ID as parameter
  const RecipeDetailScreen({super.key, required this.recipeId});

  @override
  State<RecipeDetailScreen> createState() => _RecipeDetailScreenState();
}

class _RecipeDetailScreenState extends State<RecipeDetailScreen> {
  late Future<Map<String, dynamic>> _recipeDetail;

  @override
  void initState() {
    super.initState();
    _recipeDetail = DatabaseHelper()
        .fetchRecipeDetail(widget.recipeId); // Fetch recipe details by ID
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Recipe Details'),
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _recipeDetail,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No details found'));
          }

          var recipe = snapshot.data!;

          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.network(recipe['image']),
                const SizedBox(height: 20),
                Text(
                  recipe['name'],
                  style: const TextStyle(
                      fontSize: 24, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Text('Description: ${recipe['description']}'),
                const SizedBox(height: 10),
                Text('Ingredients: ${recipe['ingredients']}'),
                const SizedBox(height: 10),
                Text('Instructions: ${recipe['instructions']}'),
              ],
            ),
          );
        },
      ),
    );
  }
}
