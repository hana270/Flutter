import 'package:mysql1/mysql1.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  MySqlConnection? _connection;

  Future<MySqlConnection> get connection async {
    if (_connection == null) {
      await connect();
    }
    return _connection!;
  }

  Future<void> connect() async {
    try {
      var settings = ConnectionSettings(
        host: '127.0.0.1',
        port: 3306,
        user: 'root',
        password: '',
        db: 'flutter_project',
      );
      _connection = await MySqlConnection.connect(settings);
      print('Connexion MySQL établie avec succès');
    } catch (e) {
      print('Erreur de connexion MySQL: $e');
      rethrow;
    }
  }

  Future<void> close() async {
    if (_connection != null) {
      await _connection!.close();
      _connection = null;
    }
  }

  Future<List<Map<String, dynamic>>> fetchRecipes() async {
    final conn = await connection;
    var results = await conn.query('SELECT * FROM recipes');
    List<Map<String, dynamic>> recipes = [];
    for (var row in results) {
      recipes.add({
        'id': row['id'],
        'name': row['name'],
        'description': row['description'],
        'ingredients': row['ingredients'],
        'instructions': row['instructions'],
      });
    }
    return recipes;
  }

  Future<Map<String, dynamic>> fetchRecipeDetail(int id) async {
    final conn = await connection;
    var results = await conn.query('SELECT * FROM recipes WHERE id = ?', [id]);
    if (results.isNotEmpty) {
      var row = results.first;
      return {
        'id': row['id'],
        'name': row['name'],
        'description': row['description'],
        'ingredients': row['ingredients'],
        'instructions': row['instructions'],
      };
    }
    return {};
  }

  Future<void> addFavorite(int recipeId) async {
    final conn = await connection;
    await conn.query(
        'INSERT INTO user_favorites (product_id) VALUES (?)', [recipeId]);
  }

  void updateQuantity(int recipeId, int newQuantity) async {
    final conn = await connection;
    await conn.query('UPDATE recipes SET quantity = ? WHERE id = ?',
        [newQuantity, recipeId]);
  }
}
