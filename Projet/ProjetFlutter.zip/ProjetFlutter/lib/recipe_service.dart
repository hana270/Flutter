import 'database_helper.dart';

class RecipeService {
  final DatabaseHelper _databaseHelper = DatabaseHelper();

  Future<List<Map<String, dynamic>>> getAllRecipes() async {
    try {
      var connection = await _databaseHelper.connection;
      var results = await connection.query(
        'SELECT id, name, image, cal, time, rate, reviews FROM recipes',
      );

      return results
          .map((row) => {
                'id': row[0],
                'name': row[1],
                'image': row[2],
                'cal': row[3],
                'time': row[4],
                'rate': row[5],
                'reviews': row[6],
              })
          .toList();
    } catch (e) {
      print('Erreur de récupération des recettes: $e');
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> getRecipesByCategory(
      String category) async {
    try {
      var connection = await _databaseHelper.connection;
      var results = await connection.query(
        'SELECT * FROM recipes WHERE category = ?',
        [category],
      );

      return results.map((row) => row.fields).toList();
    } catch (e) {
      print('Erreur de récupération des recettes par catégorie: $e');
      return [];
    }
  }
}
