import 'package:flutter/material.dart';

import 'database_helper.dart';

class FavoriteProvider with ChangeNotifier {
  List<Map<String, dynamic>> _favorites = [];

  List<Map<String, dynamic>> get favorites => _favorites;

  // Ajoutez une méthode pour charger les favoris depuis la base de données MySQL
  Future<void> loadFavorites() async {
    try {
      var recipes = await DatabaseHelper().fetchRecipes();
      _favorites = recipes; // Ici vous pouvez filtrer selon les favoris
      notifyListeners();
    } catch (e) {
      print("Erreur de récupération des favoris : $e");
    }
  }

  // Méthode pour ajouter aux favoris
  Future<void> addToFavorites(int recipeId) async {
    try {
      // Ajoutez ici la logique pour insérer un favori dans la base de données MySQL
      notifyListeners(); // Mettez à jour l'UI après modification
    } catch (e) {
      print("Erreur d'ajout aux favoris : $e");
    }
  }
}

class QuantityProvider with ChangeNotifier {
  int _quantity = 1;

  int get quantity => _quantity;

  void increment() {
    _quantity++;
    notifyListeners();
  }

  void decrement() {
    if (_quantity > 1) {
      _quantity--;
      notifyListeners();
    }
  }

  // Méthode pour mettre à jour la quantité dans la base de données MySQL
  Future<void> updateQuantityInDatabase(int recipeId) async {
    try {
      await DatabaseHelper().updateQuantity(recipeId, _quantity);
    } catch (e) {
      print("Erreur de mise à jour de la quantité : $e");
    }
  }
}
